/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.47203801945181256, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5347826086956522, 500, 1500, "Post an user"], "isController": false}, {"data": [0.59765625, 500, 1500, "Post a cover photo"], "isController": false}, {"data": [0.5971563981042654, 500, 1500, "Get all activities"], "isController": false}, {"data": [0.5678391959798995, 500, 1500, "Get authors for book"], "isController": false}, {"data": [0.5523809523809524, 500, 1500, "Get an activity"], "isController": false}, {"data": [0.38109756097560976, 500, 1500, "Delete a book"], "isController": false}, {"data": [0.5213675213675214, 500, 1500, "Get an user"], "isController": false}, {"data": [0.4898989898989899, 500, 1500, "Get all authors"], "isController": false}, {"data": [0.5580808080808081, 500, 1500, "Get an author"], "isController": false}, {"data": [0.31025641025641026, 500, 1500, "Delete an author"], "isController": false}, {"data": [0.5578512396694215, 500, 1500, "Get all users"], "isController": false}, {"data": [0.5141843971631206, 500, 1500, "Get all cover photos for a book"], "isController": false}, {"data": [0.5614035087719298, 500, 1500, "Delete an user"], "isController": false}, {"data": [0.21122994652406418, 500, 1500, "Get a book"], "isController": false}, {"data": [0.25833333333333336, 500, 1500, "Put a book"], "isController": false}, {"data": [0.5915841584158416, 500, 1500, "Delete an activity"], "isController": false}, {"data": [0.42810457516339867, 500, 1500, "Get all cover photos"], "isController": false}, {"data": [0.5766129032258065, 500, 1500, "Delete a cover photo"], "isController": false}, {"data": [0.467005076142132, 500, 1500, "Post an author"], "isController": false}, {"data": [0.553921568627451, 500, 1500, "Put an activity"], "isController": false}, {"data": [0.5, 500, 1500, "Get a cover photo"], "isController": false}, {"data": [0.5350877192982456, 500, 1500, "Put an user"], "isController": false}, {"data": [0.3629441624365482, 500, 1500, "Put an author"], "isController": false}, {"data": [0.32947976878612717, 500, 1500, "Post a book"], "isController": false}, {"data": [0.5932835820895522, 500, 1500, "Put a cover photo"], "isController": false}, {"data": [0.6328502415458938, 500, 1500, "Post an activity"], "isController": false}, {"data": [0.13402061855670103, 500, 1500, "Get all books"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4524, 0, 0.0, 1285.3636162687865, 9, 11749, 1022.0, 2480.0, 3470.5, 6166.0, 73.81542879519645, 3054.2036962017446, 18.554193546248857], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Post an user", 115, 0, 0.0, 1124.486956521739, 208, 7282, 746.0, 2337.4000000000005, 2758.3999999999996, 7239.280000000001, 2.2308438409311346, 0.6786493695441319, 0.6350782007759457], "isController": false}, {"data": ["Post a cover photo", 128, 0, 0.0, 1056.1015625000005, 208, 6127, 799.5, 2198.2, 3321.9499999999994, 5677.20999999999, 2.3301112264030728, 0.8536144314437588, 0.8457746254528243], "isController": false}, {"data": ["Get all activities", 211, 0, 0.0, 912.507109004739, 46, 6223, 704.0, 1847.6000000000001, 2236.3999999999915, 5915.079999999999, 3.5030049473719163, 10.620023963832718, 0.7047060733970847], "isController": false}, {"data": ["Get authors for book", 199, 0, 0.0, 931.668341708543, 19, 4838, 691.0, 1723.0, 2273.0, 4686.0, 3.3335566872152236, 1.5740559459595282, 0.6741840952492629], "isController": false}, {"data": ["Get an activity", 210, 0, 0.0, 821.9666666666665, 18, 3732, 682.0, 1765.2000000000003, 1974.7499999999995, 2904.3999999999896, 3.493478839499601, 1.1995999394879557, 0.7099540493162763], "isController": false}, {"data": ["Delete a book", 164, 0, 0.0, 1494.8841463414637, 225, 5671, 1249.0, 2955.5, 4367.75, 5624.849999999999, 2.7653654835174097, 0.5698165205294663, 0.6079371206053452], "isController": false}, {"data": ["Get an user", 117, 0, 0.0, 1145.4444444444443, 206, 7196, 750.0, 2600.6000000000004, 3035.3999999999983, 6970.099999999991, 2.240563779467244, 0.678912817891955, 0.44437997903062104], "isController": false}, {"data": ["Get all authors", 198, 0, 0.0, 1234.8131313131307, 38, 6725, 1103.5, 2116.899999999999, 4138.25, 6489.379999999997, 3.35627351934095, 152.44901428005392, 0.6653550043224735], "isController": false}, {"data": ["Get an author", 198, 0, 0.0, 1032.2525252525256, 12, 5557, 998.5, 1548.8, 2286.949999999998, 4929.339999999995, 3.648895195621326, 1.176939310626025, 0.7308336539170337], "isController": false}, {"data": ["Delete an author", 195, 0, 0.0, 1747.3230769230765, 28, 7354, 1430.0, 3446.0, 5201.999999999999, 7087.119999999998, 3.2821099759311934, 0.6762941454311346, 0.7278894139329777], "isController": false}, {"data": ["Get all users", 121, 0, 0.0, 1026.5537190082648, 198, 4433, 775.0, 2137.999999999999, 2758.2999999999984, 4289.120000000001, 2.2377156806539307, 1.7132510680006658, 0.43923911309710945], "isController": false}, {"data": ["Get all cover photos for a book", 141, 0, 0.0, 1189.7021276595747, 204, 6102, 979.0, 2057.7999999999997, 3104.9000000000005, 6097.8, 2.506265664160401, 0.8771860391226293, 0.5044331795801561], "isController": false}, {"data": ["Delete an user", 114, 0, 0.0, 908.6842105263157, 221, 3441, 693.5, 1812.5, 1980.25, 3421.9499999999994, 2.3402377188840764, 0.48221695184037117, 0.5144329093363168], "isController": false}, {"data": ["Get a book", 187, 0, 0.0, 2105.6203208556135, 383, 7400, 1769.0, 3483.800000000001, 5923.599999999999, 7362.16, 3.123121116975082, 14.64078822796279, 0.6194442472777073], "isController": false}, {"data": ["Put a book", 180, 0, 0.0, 1923.7055555555532, 39, 8389, 1566.0, 3446.9, 5399.449999999996, 7487.4699999999975, 3.0663350482096012, 1.1665282113471431, 1.1668442940615311], "isController": false}, {"data": ["Delete an activity", 202, 0, 0.0, 778.5792079207923, 23, 4576, 606.0, 1418.500000000001, 1687.1999999999998, 4472.899999999998, 3.3810926620246384, 0.69668999188203, 0.7597356795243037], "isController": false}, {"data": ["Get all cover photos", 153, 0, 0.0, 1302.6405228758172, 228, 5809, 1168.0, 2274.4, 3336.3999999999974, 5647.000000000003, 2.62864015118976, 53.23766415578559, 0.5313754993127738], "isController": false}, {"data": ["Delete a cover photo", 124, 0, 0.0, 1094.9032258064512, 206, 6721, 791.5, 2032.0, 3366.0, 6316.5, 2.2609171300939006, 0.4658725727048956, 0.5102269748837633], "isController": false}, {"data": ["Post an author", 197, 0, 0.0, 1376.0659898477163, 9, 5785, 1149.0, 3111.6000000000017, 4583.1, 5777.16, 3.4088942723654614, 1.0495976812597336, 1.0063207031925938], "isController": false}, {"data": ["Put an activity", 204, 0, 0.0, 866.8725490196081, 17, 5004, 690.5, 1762.5, 2129.0, 4503.649999999983, 3.4541729456983696, 1.1334004978072776, 1.1202383421663082], "isController": false}, {"data": ["Get a cover photo", 147, 0, 0.0, 1178.2517006802716, 224, 7270, 1112.0, 2108.4000000000024, 2537.9999999999995, 6709.3600000000115, 2.5272495959839083, 0.8795543143760961, 0.5160506406233882], "isController": false}, {"data": ["Put an user", 114, 0, 0.0, 1156.649122807017, 204, 7276, 751.5, 2037.5, 3907.5, 7264.15, 2.34756285908445, 0.7141267877000061, 0.6707897026420379], "isController": false}, {"data": ["Put an author", 197, 0, 0.0, 1696.111675126904, 20, 11749, 1357.0, 3365.4, 5764.399999999999, 11291.340000000006, 3.3246700644682217, 1.023665069024876, 0.9850172298494617], "isController": false}, {"data": ["Post a book", 173, 0, 0.0, 1679.4335260115618, 29, 11112, 1346.0, 2976.6, 4486.299999999997, 8330.339999999966, 2.92753917487393, 1.1133777593748941, 1.1105188343994314], "isController": false}, {"data": ["Put a cover photo", 134, 0, 0.0, 1016.0895522388059, 204, 5282, 747.0, 1984.0, 2430.25, 4947.7500000000055, 2.4004012611063343, 0.878790792266767, 0.8634664022194756], "isController": false}, {"data": ["Post an activity", 207, 0, 0.0, 818.8550724637679, 18, 4585, 577.0, 1788.800000000001, 2041.0, 4126.999999999992, 3.4694288012872088, 1.138373590020783, 1.121433019701998], "isController": false}, {"data": ["Get all books", 194, 0, 0.0, 2679.9587628865984, 221, 7485, 2178.0, 5444.5, 6051.25, 7173.400000000003, 3.239758855062541, 2879.013526567275, 0.6359292283862995], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4524, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
